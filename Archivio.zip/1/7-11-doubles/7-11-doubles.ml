let fun1 (a : int) (b : int) : bool = 
  if (a+b == 7 || a+b == 11 || a == b)
    then true
else false 