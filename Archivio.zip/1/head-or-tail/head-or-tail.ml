let hot =
  let r = Random.int 5 in
  if r mod 2=0 then "head"
  else "tail" 