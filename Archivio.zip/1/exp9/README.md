# x to the ninth

Write a function with type:
```ocaml
square : int -> int
```
such that `square x` evaluates to the square of `x`.

Use this function to write a function with type:
```ocaml
exp9: int -> int
```
which computes the 9th power of the argument.
This function should perform the lowest possible number of multiplications.
