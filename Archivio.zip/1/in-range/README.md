# In range

Write a function with type:
```ocaml
in_range : 'a -> 'a -> 'a -> bool
```
such that `in_range x a b` evaluates to true iff the value x belongs to the range a..b.