let fun1 (x : int) : int =
    if x < 0 
        then 0 - x 
    else x