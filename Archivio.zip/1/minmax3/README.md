# Min and max of three values

Write a function with type:
```ocaml
minmax3 : 'a -> 'a -> 'a -> 'a * 'a
```
such that che `minmax3 a b c` evaluates to a pair
whose left element is the minimum of a, b, c, while
the right element is the maximum.
