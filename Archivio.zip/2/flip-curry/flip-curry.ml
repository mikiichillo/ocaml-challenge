let flip f x y = f y x 
    
(*Examples*)
let f1 x y =
  x-y+1
        
let f2 x y =
  x-y+2
        
let f3 x y =
  x-y+3